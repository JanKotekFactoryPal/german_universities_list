**Předmět:** Dotaz na přijímací řízení pro zimní semestr 2025

Vážené dámy a pánové,

ráda bych se informovala o možnostech studia na Fakultě architektury ČVUT v Praze s nástupem v zimním semestru 2025.

Mám české občanství a plynně hovořím česky, ale momentálně žiji a studuji v Berlíně v Německu. Proto budu mít maturitní vysvědčení z německého gymnázia a doufám, že to nebude překážkou pro přijetí ke studiu na vaší fakultě.

Prosím o poskytnutí následujících informací:

- Termín pro podání přihlášky ke studiu v zimním semestru 2025.
- Požadavky pro přijetí (studijní výsledky, uznání zahraničního maturitního vysvědčení, portfolio).
- Odkaz na webovou stránku s podrobnými informacemi o přijímacím řízení.
- Informace o partnerských školách pro výměnné programy v oblasti architektury.
- Zda existuje možnost duálního studia a které partnerské firmy jsou do něj zapojeny.

Předem děkuji za Vaši odpověď a těším se na další komunikaci.

S pozdravem,

[Vaše jméno]

**Emailová adresa sekretariátu:** admissions@fa.cvut.cz